<?php
// Conectar ao banco de dados
$conn = new mysqli('localhost', 'root', '', 'db_tarefas');

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Consulta para obter as tarefas e seus respectivos usuários
$sql = "SELECT t.tar_codigo, t.setor, t.prioridade, t.descricao, t.status, u.nome AS usuario_nome
        FROM tarefas t
        LEFT JOIN usuarios u ON t.usu_codigo = u.usu_codigo
        ORDER BY t.tar_codigo";
$result = $conn->query($sql);

// Fechar a conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Tarefas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        header {
            background-color: #007bff;
            padding: 10px;
            text-align: center;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            font-weight: bold;
        }
        nav a:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        .actions a {
            margin-right: 10px;
            text-decoration: none;
            color: #007bff;
        }
        .actions a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="cadastro_usuarios.php">Cadastro de Usuários</a>
            <a href="cadastro_tarefas.php">Cadastro de Tarefas</a>
            <a href="gerenciar_tarefas.php">Gerenciar Tarefas</a>
        </nav>
    </header>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Setor</th>
                <th>Prioridade</th>
                <th>Descrição</th>
                <th>Status</th>
                <th>Usuário</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['tar_codigo']; ?></td>
                <td><?= $row['setor']; ?></td>
                <td><?= $row['prioridade']; ?></td>
                <td><?= $row['descricao']; ?></td>
                <td><?= $row['status']; ?></td>
                <td><?= $row['usuario_nome']; ?></td>
                <td class="actions">
                    <a href="editar_tarefa.php?id=<?= $row['tar_codigo'] ?>">Editar</a> | 
                    <a href="excluir_tarefa.php?tar_codigo=<?= $row['tar_codigo'] ?>" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>