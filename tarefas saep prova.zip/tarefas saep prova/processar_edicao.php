<?php
include 'conexao.php';

// Verificar se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar se o código da tarefa foi enviado
    if (!empty($_POST['tar_codigo'])) {
        // Obter os dados do formulário
        $tar_codigo = intval($_POST['tar_codigo']);
        $setor = mysqli_real_escape_string($conn, $_POST['setor']);
        $prioridade = mysqli_real_escape_string($conn, $_POST['prioridade']);
        $descricao = mysqli_real_escape_string($conn, $_POST['descricao']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $usu_codigo = mysqli_real_escape_string($conn, $_POST['usu_codigo']);

        // Atualizar a tarefa no banco de dados
        $sql = "UPDATE tarefas 
                SET 
                    setor = '$setor',
                    prioridade = '$prioridade',
                    descricao = '$descricao',
                    status = '$status',
                    usu_codigo = '$usu_codigo'
                WHERE tar_codigo = $tar_codigo";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Tarefa editada com sucesso!'); window.location.href='gerenciar_tarefas.php';</script>";
        } else {
            echo "Erro ao editar a tarefa: " . mysqli_error($conn);
        }
    } else {
        echo "<script>alert('ID da tarefa não encontrado.'); window.location.href='gerenciar_tarefas.php';</script>";
    }
} else {
    echo "<script>alert('Requisição inválida.'); window.location.href='gerenciar_tarefas.php';</script>";
}

// Fechar a conexão
$conn->close();
?>