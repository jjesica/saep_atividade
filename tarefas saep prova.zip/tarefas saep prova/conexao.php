<?php
$servername = "localhost";
$username = "root";
$password = ""; // deixe em branco se estiver usando o XAMPP e não tiver senha para o usuário root
$dbname = "db_tarefas";

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
echo "Conexão bem-sucedida!";
?>
